#!/usr/bin/env bash
# =============================================================================
# GEM Agent Builder — one-shot setup
# =============================================================================
# Run once after cloning. Discovers tokens from your existing CLI sessions
# (Vercel CLI, GitHub CLI) and writes everything to .env.local.
# Nothing is stored anywhere else. Re-run at any time to refresh tokens.
#
# Requirements (only what you use):
#   vercel CLI  →  brew install vercel-cli   / npm i -g vercel
#   gh CLI      →  brew install gh           (optional, for PR flow)
#   openssl     →  pre-installed on macOS/Linux
# =============================================================================

set -euo pipefail
BOLD='\033[1m'; TEAL='\033[38;5;43m'; RED='\033[31m'; RESET='\033[0m'
OK="${TEAL}✓${RESET}"; SKIP="${RED}–${RESET}"

ENV_FILE=".env.local"
echo ""
echo -e "${BOLD}${TEAL}GEM Agent Builder · Setup${RESET}"
echo "────────────────────────────────────────"
echo "Writing to: $(pwd)/${ENV_FILE}"
echo ""

# ── Helpers ──────────────────────────────────────────────────────────────────

ask() {
  # ask VAR_NAME "prompt" [default]
  local var="$1" prompt="$2" default="${3:-}"
  local current; current=$(grep "^${var}=" "${ENV_FILE}" 2>/dev/null | cut -d= -f2- || true)
  [[ -n "$current" ]] && default="$current"

  if [[ -n "$default" ]]; then
    printf "  %-30s [%s]: " "$prompt" "${default:0:32}…"
  else
    printf "  %-30s : " "$prompt"
  fi
  read -r input
  echo "${input:-$default}"
}

write_var() {
  local key="$1" val="$2"
  if [[ -z "$val" ]]; then return; fi
  # Update in place if key exists, else append
  if grep -q "^${key}=" "${ENV_FILE}" 2>/dev/null; then
    # macOS/Linux portable sed
    if [[ "$OSTYPE" == "darwin"* ]]; then
      sed -i '' "s|^${key}=.*|${key}=${val}|" "${ENV_FILE}"
    else
      sed -i "s|^${key}=.*|${key}=${val}|" "${ENV_FILE}"
    fi
  else
    echo "${key}=${val}" >> "${ENV_FILE}"
  fi
}

section() { echo ""; echo -e "${BOLD}$1${RESET}"; echo "────────────────────"; }

# ── Ensure .env.local exists ─────────────────────────────────────────────────
touch "${ENV_FILE}"

# ── 1. Anthropic ─────────────────────────────────────────────────────────────
section "1 · Anthropic"

ANTHROPIC_API_KEY=$(ask "ANTHROPIC_API_KEY" "Anthropic API key (sk-ant-…)")
if [[ -z "$ANTHROPIC_API_KEY" ]]; then
  echo -e "  ${RED}ERROR: ANTHROPIC_API_KEY is required.${RESET}"
  echo "  Get one at https://console.anthropic.com/settings/keys"
  exit 1
fi
write_var "ANTHROPIC_API_KEY" "$ANTHROPIC_API_KEY"
write_var "ANTHROPIC_MODEL"   "claude-sonnet-4-6"
echo -e "  ${OK} ANTHROPIC_API_KEY set"
echo -e "  ${OK} ANTHROPIC_MODEL = claude-sonnet-4-6"

# ── 2. Vercel ─────────────────────────────────────────────────────────────────
section "2 · Vercel"

VERCEL_TOKEN=""
VERCEL_TEAM_ID=""
VERCEL_PROJECT_ID=""

if command -v vercel &>/dev/null; then
  # Pull token from vercel CLI credential store
  VERCEL_TOKEN=$(vercel whoami --token 2>/dev/null || true)

  # The CLI stores the token in ~/.local/share/com.vercel.cli/auth.json (Linux)
  # or ~/Library/Application Support/com.vercel.cli/auth.json (macOS)
  if [[ -z "$VERCEL_TOKEN" ]]; then
    for auth_path in \
      "$HOME/Library/Application Support/com.vercel.cli/auth.json" \
      "$HOME/.local/share/com.vercel.cli/auth.json" \
      "$HOME/.config/vercel/auth.json"; do
      if [[ -f "$auth_path" ]]; then
        VERCEL_TOKEN=$(python3 -c "import json,sys; d=json.load(open('$auth_path')); print(list(d.get('tokens',{}).values())[0].get('token',''))" 2>/dev/null || true)
        [[ -n "$VERCEL_TOKEN" ]] && break
      fi
    done
  fi

  if [[ -n "$VERCEL_TOKEN" ]]; then
    echo -e "  ${OK} Detected Vercel token from CLI"
  fi

  # Pull team + project from .vercel/project.json if linked
  if [[ -f ".vercel/project.json" ]]; then
    VERCEL_TEAM_ID=$(python3 -c "import json; d=json.load(open('.vercel/project.json')); print(d.get('orgId',''))" 2>/dev/null || true)
    VERCEL_PROJECT_ID=$(python3 -c "import json; d=json.load(open('.vercel/project.json')); print(d.get('projectId',''))" 2>/dev/null || true)
    [[ -n "$VERCEL_TEAM_ID" ]]    && echo -e "  ${OK} VERCEL_TEAM_ID    = $VERCEL_TEAM_ID"
    [[ -n "$VERCEL_PROJECT_ID" ]] && echo -e "  ${OK} VERCEL_PROJECT_ID = $VERCEL_PROJECT_ID"
  fi
else
  echo -e "  ${SKIP} vercel CLI not found — enter token manually"
  echo "     Install: npm i -g vercel && vercel login"
fi

# Manual fallback for anything not auto-detected
[[ -z "$VERCEL_TOKEN" ]]     && VERCEL_TOKEN=$(ask "VERCEL_TOKEN" "Vercel access token")
[[ -z "$VERCEL_TEAM_ID" ]]   && VERCEL_TEAM_ID=$(ask "VERCEL_TEAM_ID" "Vercel team ID (team_…)")
[[ -z "$VERCEL_PROJECT_ID" ]] && VERCEL_PROJECT_ID=$(ask "VERCEL_PROJECT_ID" "Vercel project ID (prj_…)")

write_var "VERCEL_TOKEN"      "$VERCEL_TOKEN"
write_var "VERCEL_TEAM_ID"    "$VERCEL_TEAM_ID"
write_var "VERCEL_PROJECT_ID" "$VERCEL_PROJECT_ID"

# ── 2b. Auto-create deploy hook via Vercel API ────────────────────────────────
VERCEL_DEPLOY_HOOK_URL=""
if [[ -n "$VERCEL_TOKEN" && -n "$VERCEL_PROJECT_ID" ]]; then
  echo "  Creating deploy hook via Vercel API…"

  TEAM_QUERY=""
  [[ -n "$VERCEL_TEAM_ID" ]] && TEAM_QUERY="?teamId=${VERCEL_TEAM_ID}"

  HOOK_RESPONSE=$(curl -s -X POST \
    "https://api.vercel.com/v1/projects/${VERCEL_PROJECT_ID}/deploy-hooks${TEAM_QUERY}" \
    -H "Authorization: Bearer ${VERCEL_TOKEN}" \
    -H "Content-Type: application/json" \
    -d '{"name":"gem-agent","ref":"main"}' 2>/dev/null || true)

  VERCEL_DEPLOY_HOOK_URL=$(echo "$HOOK_RESPONSE" | \
    python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('hook',{}).get('url',''))" 2>/dev/null || true)

  if [[ -n "$VERCEL_DEPLOY_HOOK_URL" ]]; then
    echo -e "  ${OK} Deploy hook created automatically"
  else
    echo -e "  ${SKIP} Could not auto-create hook (check token scope)"
    echo "     Manual: Vercel dashboard → Project → Settings → Git → Deploy Hooks"
    VERCEL_DEPLOY_HOOK_URL=$(ask "VERCEL_DEPLOY_HOOK_URL" "Deploy hook URL (optional)")
  fi
fi
write_var "VERCEL_DEPLOY_HOOK_URL" "$VERCEL_DEPLOY_HOOK_URL"

# ── 3. GitHub ─────────────────────────────────────────────────────────────────
section "3 · GitHub (optional — required for PR flow)"

GITHUB_TOKEN=""
GITHUB_DEFAULT_OWNER=""

if command -v gh &>/dev/null && gh auth status &>/dev/null 2>&1; then
  GITHUB_TOKEN=$(gh auth token 2>/dev/null || true)
  GITHUB_DEFAULT_OWNER=$(gh api user --jq '.login' 2>/dev/null || true)
  [[ -n "$GITHUB_TOKEN" ]]        && echo -e "  ${OK} GitHub token from gh CLI"
  [[ -n "$GITHUB_DEFAULT_OWNER" ]] && echo -e "  ${OK} GITHUB_DEFAULT_OWNER = $GITHUB_DEFAULT_OWNER"
else
  echo -e "  ${SKIP} gh CLI not found or not logged in (skipping PR flow)"
  echo "     Install: brew install gh && gh auth login"
  GITHUB_TOKEN=$(ask "GITHUB_TOKEN" "GitHub token (optional, PAT)")
  GITHUB_DEFAULT_OWNER=$(ask "GITHUB_DEFAULT_OWNER" "GitHub owner/org (optional)")
fi

write_var "GITHUB_TOKEN"          "$GITHUB_TOKEN"
write_var "GITHUB_DEFAULT_OWNER"  "$GITHUB_DEFAULT_OWNER"

# ── 4. GEM Agent Token (auth gate) ───────────────────────────────────────────
section "4 · GEM Agent auth token"

GEM_AGENT_TOKEN=""
EXISTING=$(grep "^GEM_AGENT_TOKEN=" "${ENV_FILE}" 2>/dev/null | cut -d= -f2- || true)

if [[ -n "$EXISTING" ]]; then
  GEM_AGENT_TOKEN="$EXISTING"
  echo -e "  ${OK} Existing token kept (${GEM_AGENT_TOKEN:0:12}…)"
else
  GEM_AGENT_TOKEN=$(openssl rand -hex 32)
  echo -e "  ${OK} Generated: ${GEM_AGENT_TOKEN:0:12}…"
  echo ""
  echo -e "  ${BOLD}SAVE THIS — it protects your /api/agent and /api/deploy endpoints:${RESET}"
  echo -e "  ${TEAL}${GEM_AGENT_TOKEN}${RESET}"
fi

write_var "GEM_AGENT_TOKEN" "$GEM_AGENT_TOKEN"

# ── 5. Write remaining defaults ───────────────────────────────────────────────
write_var "NODE_ENV" "development"

# ── 6. Push to Vercel project env (non-interactive) ──────────────────────────
section "5 · Push to Vercel project env"

if command -v vercel &>/dev/null && [[ -n "$VERCEL_TOKEN" ]]; then
  echo "  Pushing secrets to Vercel project…"

  push_env() {
    local key="$1" val="$2"
    [[ -z "$val" ]] && return
    echo "$val" | vercel env add "$key" production --yes --token "$VERCEL_TOKEN" 2>/dev/null \
      && echo -e "  ${OK} $key" \
      || echo -e "  ${SKIP} $key (already set or permission denied)"
  }

  push_env "ANTHROPIC_API_KEY"       "$ANTHROPIC_API_KEY"
  push_env "ANTHROPIC_MODEL"         "claude-sonnet-4-6"
  push_env "VERCEL_TOKEN"            "$VERCEL_TOKEN"
  push_env "VERCEL_TEAM_ID"          "$VERCEL_TEAM_ID"
  push_env "VERCEL_PROJECT_ID"       "$VERCEL_PROJECT_ID"
  push_env "VERCEL_DEPLOY_HOOK_URL"  "$VERCEL_DEPLOY_HOOK_URL"
  push_env "GITHUB_TOKEN"            "$GITHUB_TOKEN"
  push_env "GITHUB_DEFAULT_OWNER"    "$GITHUB_DEFAULT_OWNER"
  push_env "GEM_AGENT_TOKEN"         "$GEM_AGENT_TOKEN"
  push_env "NODE_ENV"                "production"
else
  echo -e "  ${SKIP} vercel CLI not available — skipping push"
  echo "     Run: vercel env add <KEY> production  for each var manually"
  echo "     Or:  re-run this script after: npm i -g vercel && vercel login"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════"
echo -e "${BOLD}${TEAL}Setup complete.${RESET}"
echo ""
echo "  Local dev:  pnpm dev"
echo "  Deploy:     vercel --prod"
echo ""
echo "  ${ENV_FILE} written. Never commit this file."
echo "════════════════════════════════════════"
echo ""
